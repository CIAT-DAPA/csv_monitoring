#Ya aprendi a cargar bases de datos, libfrerias e instalar librerias.
library(readr)
library(dplyr)
mtcars <- read_csv("D:/OneDrive - CGIAR/Desktop/mtcars.csv")
mtcars %>% View()
View(mtcars)

#Ahora voy a aprender a hacer operaciones y graficos basicos con la base de datos
mtcars$drat #Se usa $ para  cargar las variables de las bases de datos
mtcars$hp %>% mean() 
mean(mtcars$hp)
mtcars$hp %>% summary()#En esta función se aplica el operador solo a la variable
summary(mtcars) #Para que funcione la variable se debe poner CONTROL + ENTER
View(mtcars$am)
mtcars$wt %>% var() #Recordar que control + shif+M es asiganar %>% 
mtcars$wt %>% sd()

#ahora vamos a hacer un grafico
mtcars$mpg %>% hist()
hist(mtcars$mpg)
boxplot(mtcars$mpg)
plot(mtcars$mpg)
plot(mtcars$mpg,mtcars$hp)
cor(mtcars$mpg,mtcars$hp)#Tener cuidado y escribir las variables bien. 
#R es un lenguaje oriendado a objetos.Esto quiere decir que yo trabajo con objetos. Stata no es orientada a objetos
class(mtcars) #data.frame es un tipo de matriz
class(mtcars$mpg) #mpg es otro objeto dentro del data.frame es un objeto de tipo numerico 
x=10 #Puede ser un numero, una matriz o un vector
z=5
y=x+z #R distingue mayusculas de minusculas. 

#vamos a crear un modelo de regresión MCO

y= lm(mtcars$mpg~mtcars$hp)
?lm #Aquí en ayuda debo buscar que son los valores QQ fitt, y otroas descripciones de objetos
y= lm(mtcars$mpg~mtcars$hp+mtcars$drat)

#como operar bases de datos
#las funciones que vamos a ver en esta sección, están dentro del paquete dplyr
names(mtcars) #me devuelve los nombres de las variables de una base
VariablesASeleccionar=c("mpg",  "cyl",  "disp", "hp",   "drat", "wt","vs")

#vamos a saleccionar solo las variables que hay en VariablesASeleccionar
mtcarsReducido=mtcars %>% select(VariablesASeleccionar)

#ahora vamos a aprender a filtrar
# != operador de diferente
mtcarsReducido2=mtcarsReducido %>% filter(vs=="1")
mtcarsReducido3=mtcarsReducido2 %>% filter(wt>2.22)
