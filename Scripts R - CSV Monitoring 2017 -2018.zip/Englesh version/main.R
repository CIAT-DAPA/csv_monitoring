library("printr")
library("tidyr")
library("readr")
library("dplyr")
library("highcharter")
library(devtools)
library("janitor")
library(devtools)
library(rpivotTable)
library(flextable)
library(officer)
library(httpuv)
library(knitr)
library(kableExtra)
library(car)
library(tools)
library(stringr)


##################################################################################################################################
#MAIN
##################################################################################################################################

#################################################################
##Tema para graficos 
#################################################################
thm1=hc_theme_gridlight()
thm1$title$style$fontSize="24px"
thm1$xAxis$labels$style$fontSize= "18px"
thm1$yAxis$labels$style$fontSize= "18px"
thm1$yAxis$title$style$fontSize= "18px"
thm1$xAxis$title$style$fontSize= "18px"
thm1$tooltip$style$fontSize="16px"
thm1$tooltip$headerFormat='<span style="font-size: 16px">{point.key}</span><br/>'
thm1$tooltip$pointFormat='<span style="color:{point.color}">\u25CF</span> {series.name} <br/> <b>{point.percentage:.0f}%</b>'
thm1$legend$itemStyle$fontSize="18px"
thm1$title$style$textTransform=NULL
thm1$yAxis$title$style$textTransform=NULL
thm1$xAxis$title$style$textTransform=NULL
#7798BF verde que no me gusta
#A1BE95
thm1$colors=c("#7CB5EC", "#F7A35C", "#90EE7E", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
thmPIE=thm1
thmPIE$colors=c( "#f5a9a9","#a9a9f5", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
thmHS=thm1
thmHS$colors=c("#b5e6e9", "#f5a9a9","#a9a9f5", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
#################################################################

#################################################################
##Funciones de tacometros
#################################################################
tacometro1=function(Valor,Nombre,yt=NULL,VR=NULL){
  if(identical(Valor, numeric(0))){
    Valor=0
  }
  if(is.null(yt)){yt=120}
  if(is.null(VR)){stopsCol=c('#DF5353','#DDDF0D','#55BF3B')} #si queremos que el grafico vaya de rojo a verde dejamos el parametro VR en null
  if(!is.null(VR)){stopsCol=c('#55BF3B','#DDDF0D','#DF5353')} #si queremos que vaya de verde a rijo le ponemos cualquier cosa
  
  highchart() %>%
    hc_chart(type = "solidgauge") %>%
    hc_title(y=yt,text = Nombre) %>%
    hc_pane(startAngle = -90,
            endAngle = 90,
            background= list(
              outerRadius = '100%',
              innerRadius = '60%',
              shape="arc"
            )) %>%  
    hc_yAxis(
      stops=list_parse2(data.frame(q = c(0.25,0.75,1), c = stopsCol,stringsAsFactors = FALSE)),
      lineWidth=0,
      minorTickWidth=0,
      tickAmount=2,
      min = 0,
      max = 100,
      labels=list(y=26,style = list(fontSize = "18px"),format = "{value}%")
    ) %>%
    hc_add_series(data = Valor,
                  dataLabels=list(y=-50,borderWidth=0, useHTML=TRUE,style = list(fontSize = "25px"),format = "{point.y}%")) %>%
    hc_add_theme(thm1)%>%
    hc_tooltip(enabled=FALSE)
}
#################################################################
#################################################################

FinishTacometro=function(basetac,filtro,HogarAgri,VR=NULL,NombreM=NULL,NombreH=NULL){
  
  if(is.null(NombreM) & is.null(NombreH)){
    NombreM= "Female"
    NombreH= "Male"
  }
  
  In19=basetac %>%
    #filter(`HEAD`==1 | `HEAD`==0)%>%
    group_by_at(c(1,2,3)) %>% 
    summarise(count = n())
  
  names(In19)=c("gender", "HEAD", "variab", "count")
  
  In19=In19[!is.na(In19$variab),]
  
  #In19$`HEAD`=if_else(In19$`HEAD`=="1","Si","No")
  
  Sex=In19 %>% group_by_at(c(1,3)) %>% summarise(count = sum(count)) %>% mutate(prop=round(count/sum(count)*100,0))
  
  SexH=Sex%>%filter(gender=="Male" & variab==filtro)
  SexM=Sex%>%filter(gender=="Female" & variab==filtro)
  
  if(HogarAgri=="Households"){
    #############
    hogares=In19 %>% na.omit() %>% group_by_at(c(2,3)) %>% summarise(count = sum(count)) %>% mutate(prop=round(count/sum(count)*100,0))
    
    hogares1=hogares %>% filter(`HEAD`==1 & variab==filtro)
    
    names(hogares)=c("Households","count","prop")
    ##########
    return(hw_grid(tacometro1(hogares1$prop,"Households",VR=VR),tacometro1(SexH$prop,NombreH,VR=VR),tacometro1(SexM$prop,NombreM,VR=VR)))
  }
  
  else{
    Agric=basetac %>%
      #filter(`HEAD`==1 | `HEAD`==0)%>%
      group_by_at(c(3)) %>% 
      summarise(count = n())%>%
      na.omit()%>% 
      mutate(prop=round(count/sum(count)*100,0))
    
    names(Agric)=c("variab", "count","prop")
    
    Agric=Agric%>% 
      filter(variab==filtro)
    
    return(hw_grid(tacometro1(Agric$prop,"Farmers",VR=VR),tacometro1(SexM$prop,NombreM,VR=VR),tacometro1(SexH$prop,NombreH,VR=VR)))
  }
}
#################################################################


#################################################################
#Función para multiple Choise
#################################################################
multiple_Choise=function(base19,VariA){
  retornador=list()
  I45c=list()
  I45cH=list()
  Variable=base19[,VariA]
  
  #Desintegramos la variables usando los | como separadores
  yy = Map(function(x,y)cbind.data.frame(y,x),strsplit(Variable,"|",fixed=TRUE),base19$farmer_id)
  base19EX=do.call("rbind",yy)
  names(base19EX)=c("farmer_id","pre")
  base19EX=merge(base19EX,base19[c("farmer_id","gender","HEAD")],by="farmer_id")
  
  #CIAT/ NOMASI/ CCAFS | Commercial / private company | Don't know | Government agricultural extension or Meteorogical office | Relative, neighbor or expert within the community

    I45c=base19EX %>%
      filter(!is.na(pre))%>%
      group_by(gender,pre) %>%
      summarise(count = n()) %>%
      merge(base19 %>%
              filter(!is.na(Variable))%>%
              group_by(gender) %>%
              summarise(N = n()),by="gender")%>%
      mutate(prop=round(count/N*100))%>%
      select(c("gender","pre","prop","N"))
    
    retornador$TablaGBruta1=I45c2=I45c
    
    I45c2$prop=paste(I45c2$prop,"%",sep="")
    
    retornador$TablaGBruta=I45c2%>%
      rename("Percentage"="prop","Number of farmers"="gender") %>% 
      select(c("Number of farmers","pre","Percentage","N"))%>%
      spread("pre", Percentage, fill="0%")
    
    
    
    retornador$TablaG=retornador$TablaGBruta%>% 
      kable() %>%
      kable_styling("striped", full_width = F)
    
    retornador$hcG=hchart(I45c, "column", hcaes(x = pre, y = prop, group=`gender`),
                          dataLabels = list(enabled = TRUE,format = paste('<b>{point.prop}%</b>'), style=list(fontSize="17px"))) %>%
      hc_tooltip(pointFormat = paste('<b>{point.prop}%</b>'))%>%
      hc_title(text = paste(" "),
               margin = 20, align = "center",style = list(useHTML = TRUE)) %>%
      # hc_legend(align = "center")%>%
      hc_add_theme(thmPIE)%>%
      hc_xAxis(title = list(text = " ")) %>%
      hc_yAxis(title = list(text = "Percentage of farmers"),labels = list(format = "{value}%"), max = 100)
    
    
    #Lo mismo pero para agricultores en general
    
    I45cH=base19EX %>%
      #filter(`HEAD`=="1") %>%
      filter(!is.na(pre))%>%
      group_by(pre) %>%
      summarise(count = n()) %>%
      merge(base19 %>%
              filter(!is.na(Variable)) %>% # & `HEAD`==1)%>%
              summarise(N = n()))%>%
      mutate(prop=round(count/N*100))%>%
      select(c("pre","prop","N"))

    retornador$TablaFBruta1=I45cH2=I45cH
    
    I45cH2$prop=paste(I45cH2$prop,"%",sep="")
    
    retornador$TablaFBruta=I45cH2%>%
      rename("Percentage"="prop") %>% 
      mutate("Number of farmers"="Farmers") %>% 
      select(c("Number of farmers","pre","Percentage","N"))%>%
      spread("pre", Percentage, fill="0%")
    
    retornador$TablaF=retornador$TablaFBruta %>% 
      kable() %>%
      kable_styling("striped", full_width = F)
    
    retornador$hcF=hchart(I45cH, "column", hcaes(x = pre, y = prop),
           dataLabels = list(enabled = TRUE,format = paste('<b>{point.prop}%</b>'), style=list(fontSize="17px"))) %>%
      hc_tooltip(pointFormat = paste('<b>{point.prop}%</b>'))%>%
      hc_title(text = paste(" "),
               margin = 20, align = "center",style = list(useHTML = TRUE)) %>%
      # hc_legend(align = "center")%>%
      hc_add_theme(thm1)%>%
      hc_xAxis(title = list(text = " ")) %>%
      hc_yAxis(title = list(text = "Percentage of farmers"),labels = list(format = "{value}%"), max = 100)
  
    retornador$tablaFyG=dplyr::bind_rows(retornador$TablaFBruta,retornador$TablaGBruta)%>% 
                                  kable() %>%
                                  kable_styling("striped", full_width = F)
    
    I45cH=I45cH %>% mutate(gender="Farmers")
    
    tablaFyGBruta=dplyr::bind_rows(I45c,I45cH)
    retornador$tablaFyGBruta=tablaFyGBruta
    
    retornador$HFandHM=hchart(tablaFyGBruta, "column", hcaes(x = pre, y = prop,group=gender),
                          dataLabels = list(enabled = TRUE,format = paste('<b>{point.prop}%</b>'), style=list(fontSize="13px"))) %>%
      hc_tooltip(pointFormat = paste('<b>{point.prop}%</b>'))%>%
      hc_title(text = paste(" "),
               margin = 20, align = "center",style = list(useHTML = TRUE)) %>%
      # hc_legend(align = "center")%>%
      hc_add_theme(thmHS)%>%
      hc_xAxis(title = list(text = " ")) %>%
      hc_yAxis(title = list(text = "Percentage of farmers"),labels = list(format = "{value}%"), max = 100)
    
    return(retornador)
}

#################################################################
##Función arreglador, para las preguntas donde se podía devolver y no se reescribía la información
#################################################################
arreglador=function(cadena){
  patron="\\|"
  answer_type=if_else(c("multiple_choice") %in% cadena,"multiple_choice","Other_type")
  
  if(answer_type!="multiple_choice" & sum(grepl(patron, cadena))!=0){
    cadena2=grep(pattern = patron, cadena, value = T)
    posiciones=stringr::str_locate_all(cadena2, patron)
    posiciones2=lapply(posiciones, max)
    cadena2=substr(cadena2, unlist(posiciones2, use.names=FALSE)+1, nchar(cadena2))
    cadena=replace(cadena,which(grepl("\\|", cadena)),cadena2)
    return(cadena)
  }
  if(answer_type=="multiple_choice" | sum(grepl(patron, cadena))==0){
    return(cadena)
  }
}

#################################################################
#Carga de bases de datos.
#################################################################
#D:\OneDrive - CGIAR\Documents\Paginas de procesamiento rapido\XXXXX\New Codes

bases=NULL
M2=NULL
#Uganda = hoima
#
TeSACFolders=c("Ghana","Uganda","Bangladesh Khulna","Bangladesh barisal","Nepal Nawalparasi","Nepal Bardiya","Nepal Mahottari")
idiomas=c("in")

for(p in 1:length(TeSACFolders)){
  for (i in 0:5){
    M2[[i+1]]<- read_delim(paste("D:/OneDrive - CGIAR/Documents/Paginas de procesamiento rapido/",TeSACFolders[p],"/New Codes/M",i,".csv",sep=""), 
                           "\t", escape_double = FALSE, trim_ws = TRUE)
    #, locale = locale(encoding = 'ISO-8859-1')
    M2[[i+1]][M2[[i+1]]=="Yes"]=1
    M2[[i+1]][M2[[i+1]]=="No"]=0
  
    M2[[i+1]]=apply(M2[[i+1]], 2, arreglador) %>% as.data.frame()
    #M2[[i+1]]=lapply(M2[[i+1]], as.character) %>% as.data.frame()
    M2[[i+1]] <- data.frame(lapply(M2[[i+1]], as.character), stringsAsFactors=FALSE)
    
    }
  names(M2)=c("M0","M1","M2","M3","M4","M5")
  bases[[p]]=M2
}
names(bases)=TeSACFolders
#################################################################


#################################################################
#Carga de questionarios
#################################################################
#D:\OneDrive - CGIAR\Documents\Indicadores sistematizados\Ghana\Ghana\Questions\Questions_

#Uganda = hoima
#
TeSACFolders=c("Ghana","Uganda","Bangladesh Khulna","Bangladesh barisal","Nepal Nawalparasi","Nepal Bardiya","Nepal Mahottari")

Questions=NULL

for(p in 1:length(TeSACFolders)){
  Questions[[p]] <- read_excel(paste("Questions/Questions_",TeSACFolders[p],".xlsx",sep=""), 
                           col_types = c("blank", "blank", "blank", 
                                         "text", "blank", "text", "text", 
                                         "blank")) %>% t()
  colnames(Questions[[p]])=Questions[[p]][1,]
  Questions[[p]]=Questions[[p]][c(2,3),] %>% as.data.frame()
}
names(Questions)=TeSACFolders

#################################################################

#################################################################
#Nombres de prácticas por TeSAC
#################################################################
practica=NULL
#practica$Olopa=c("Variedades mejoradas de frijol","Huerto de hortalizas con cosecha de agua","Huerto de hortalizas sin cosecha de agua","Riego")
#practica$Cauca=c("Frijol restistente a sequia/biofortificado","Abono orgánico","Huerta adaptada al clima","Barreras rompe viento","Retención/incorporación de residuos de cultivos","Cosecha de agua","implementó Riego","Almacenamiento de agua en tanques de ferrocemento","Bomba tipo camándula")
#practica$`Santa Rita`=c("Variedades mejoradas de frijol rojo","Huertas de hortalizas con cosecha de agua","Huertas de hortalizas sin cosecha de agua","Secadoras solares de granos")
#practica$Nicaragua=c("Diversificación de cultivos y actividades productivas en el patio","Cultivos perennes y sistemas ganaderos con sombra diversificada y regulada","No quema y uso de residuos como cobertura muerta en cultivos anuales","Proteción de fuentes de agua en la finca","Uso de opciones no sintéticas para fertilización y manejo de plagas y enfermedades en cultivos","Uso de variedades más tolerantes o mejor adaptadas a condiciones adversas del clima")
#practica$Ghana=c("crop rotation","improved varieties","integrated nutrient management","intercropping","mulching","no/reduced tillage","new cropping system & additional crops (Home gardens)")
#practica$Uganda=c()
#practica$Bangladesh_Khulna=c("crop rotation","improved varieties","integrated nutrient management","intercropping","mulching","no/reduced tillage","new cropping system & additional crops (Home gardens)")
#practica$Bangladesh_barisal=c("crop rotation","improved varieties","integrated nutrient management","intercropping","mulching","no/reduced tillage","new cropping system & additional crops (Home gardens)")
#practica$Nepal_Nawalparasi=c()
#################################################################

#################################################################
#Funcion para dejar los nuevos codigos como nombres de las variables (tambien quita las preguntas y los tipos de variables.)
#################################################################
cambCod <- function(BD){
  
  ##########CONSIDERAR LOS IDIOMAS PARA QUE NO CAMBIO EL GENDER EN LOS SITIOS EN INGLES  
  BD$gender = car::recode(BD$gender, "'female'='Female'; 'male'='Male'")
  
  New_codes <-BD %>% filter(farmer_id=="QUESTION" | farmer_id=="QUESTION_CODE" )%>% t()%>% as.data.frame()
  New_codes$old_codes=row.names(New_codes)
  names(New_codes)=c("question","new_codes","old_codes")
  New_codes$new_codes=as.character(New_codes$new_codes)
  New_codes$new_codes[New_codes$new_codes=="QUESTION_CODE"]="--"
  New_codes$new_codes[is.na(New_codes$new_codes)]="--"
  New_codes$question[New_codes$question=="QUESTION"]="--"
  
  New_codes$new_codes[New_codes$new_codes=="--"]=New_codes$old_codes[New_codes$new_codes=="--"]
  
  BD=BD %>% filter(farmer_id!="QUESTION TYPE" & farmer_id!="QUESTION" & farmer_id!="QUESTION_CODE")
  BD=BD[,!names(BD)%in%c("X__1")]
  
  New_codes2=New_codes %>% filter(old_codes%in%names(BD)) %>% select(new_codes)
  names(BD)= New_codes2$new_codes
  
  return(BD)
}
#################################################################

#################################################################
#TypeVar Funcion que deja un data frame con el code de la variable y el tipo de variable, necesario para algunos filtros
#################################################################
# TypeVar <- function(BD){
#   
#   ##########CONSIDERAR LOS IDIOMAS PARA QUE NO CAMBIO EL GENDER EN LOS SITIOS EN INGLES  
#   BD$gender = car::recode(BD$gender, "'female'='Female'; 'male'='Male'")
#   
#   New_codes <-BD %>% filter(farmer_id=="QUESTION" | farmer_id=="QUESTION_CODE" )%>% t()%>% as.data.frame()
#   New_codes$old_codes=row.names(New_codes)
#   names(New_codes)=c("question","new_codes","old_codes")
#   New_codes$new_codes=as.character(New_codes$new_codes)
#   New_codes$new_codes[New_codes$new_codes=="QUESTION_CODE"]="--"
#   New_codes$new_codes[is.na(New_codes$new_codes)]="--"
#   New_codes$question[New_codes$question=="QUESTION"]="--"
#   
#   New_codes$new_codes[New_codes$new_codes=="--"]=New_codes$old_codes[New_codes$new_codes=="--"]
#   
#   #farmer_id=="QUESTION TYPE" & 
#   BD=BD %>% filter(farmer_id!="QUESTION" & farmer_id!="QUESTION_CODE")
#   BD=BD[,!names(BD)%in%c("X__1")]
#   
#   New_codes2=New_codes %>% filter(old_codes%in%names(BD)) %>% select(new_codes)
#   names(BD)= New_codes2$new_codes
#   
#   BD=BD %>% filter(farmer_id=="QUESTION TYPE")
#   
#   return(BD)
# }
# #################################################################
# 
# #################################################################
# #QuestionVar Funcion que deja un data frame con el code de la variable y als preguntas
# #################################################################
# QuestionVar <- function(BD){
#   
#   ##########CONSIDERAR LOS IDIOMAS PARA QUE NO CAMBIO EL GENDER EN LOS SITIOS EN INGLES  
#   BD$gender = car::recode(BD$gender, "'female'='Female'; 'male'='Male'")
#   
#   New_codes <-BD %>% filter(farmer_id=="QUESTION" | farmer_id=="QUESTION_CODE" )%>% t()%>% as.data.frame()
#   New_codes$old_codes=row.names(New_codes)
#   names(New_codes)=c("question","new_codes","old_codes")
#   New_codes$new_codes=as.character(New_codes$new_codes)
#   New_codes$new_codes[New_codes$new_codes=="QUESTION_CODE"]="--"
#   New_codes$new_codes[is.na(New_codes$new_codes)]="--"
#   New_codes$question[New_codes$question=="QUESTION"]="--"
#   
#   New_codes$new_codes[New_codes$new_codes=="--"]=New_codes$old_codes[New_codes$new_codes=="--"]
#   
#   #farmer_id=="QUESTION TYPE" & 
#   BD=BD %>% filter(farmer_id!="QUESTION TYPE" & farmer_id!="QUESTION_CODE")
#   BD=BD[,!names(BD)%in%c("X__1")]
#   
#   New_codes2=New_codes %>% filter(old_codes%in%names(BD)) %>% select(new_codes)
#   names(BD)= New_codes2$new_codes
#   
#   BD=BD %>% filter(farmer_id=="QUESTION")
#   
#   return(BD)
# }
# #################################################################


#################################################################
#lapply anidado, funcion para aplicar la función anterior a todas las bases
#################################################################
nested_lapply <- function(data, fun) {
  lapply(data, function(sublist) { lapply(sublist, fun) })
}
#################################################################

#Base definitiva con la que vamos a trabajar
bases_New_Codes=nested_lapply(bases,cambCod)
#bases_TypeVar=nested_lapply(bases,TypeVar)
#bases_QuestionVar=nested_lapply(bases,QuestionVar)

#################################################################
#Contextos para cada uno de los TeSAC
#################################################################
contextos=NULL
contextos$ghana="Acá va el contexto de ghana que no lo he encontrado en linea"
#################################################################

#################################################################
#Función donde
#################################################################
recodificaciones <- function(M, j) {
  lapply(data, function(sublist) { lapply(sublist, fun) })
}
#################################################################

#################################################################
#Esta base contiene los codigos y los nombres de las practicas por TeSAC
#################################################################
library(readxl)
#CSA_typology <- CSA_typology2 %>%  filter(subgeo==5)

CSA_typology2 <- read_excel("CSA_typology.xlsx") 
practica=NULL

for(k in 1:length(TeSACFolders)){
  CSA_typology3 = CSA_typology2 %>% filter(subgeo==k+4)
  practica[[k]]=CSA_typology3$CSA_practice_name
}

names(practica)=TeSACFolders

Climate_events <- read_excel("Climate_events.xlsx",na = "NA")
#################################################################

#################################################################
#Base de datos que contiene el inicio de las preguntas "automaticas"
#################################################################
Quest <- read_excel("Quest.xlsx")
#################################################################

# for (j in 1:length(TeSACFolders)) {
for (j in 6:7) {
    
  NombreParaFiltros=TeSACFolders[j]
  
  CSA_typology <- CSA_typology2 %>%  filter(subgeo==j+4)
  
  M=bases_New_Codes[[TeSACFolders[j]]]
  M_TypeVar=Questions[[j]][2,]
  M_TypeVar=lapply(M_TypeVar, as.character)

  M_QuestionVar=Questions[[j]][1,]
  M_QuestionVar=lapply(M_QuestionVar, as.character)
  #idioma=idiomas[j]
  
  # if(idioma=="es"){
  #   #################################################################
  #   # se encuentran las recodificaciones de las bases
  #   #################################################################
  #   #Algunos cambios pequeños que le hacemos a las bases
  #   #cambios pagina 1
      M$M1$CCC0 = car::recode(M$M1$CCC0, "'I  did changes but not because of climate'='Autonomous change (not because of climate)'; 
                               'Yes, changes were done because of climate'='Climate driven changes';
                              'I did not do any change at all'='Without changes'")
      M$M1$CCA0 = car::recode(M$M1$CCA0, "'I  did changes but not because of climate'='Autonomous change (not because of climate)'; 
                                          'Yes, changes were done because of climate'='Climate driven changes';
                                          'I did not do any change at all'='Without changes';
                                          'I did not have livestock'='Without livestock'")
  #   M$M3$ADIC = car::recode(M$M3$ADIC, "'No tuvimos otros ingresos'='Sin fuentes adicionales'; 'Si,dinero enviado por un familiar que no vive en la finca'='Remesas'; 'Si,subsidios del gobierno'='Subsidios'; 'Si,una pensón'='Pensión'")
  #   #cambios pagina 2
      M$M3$OFTY  = car::recode(M$M3$OFTY, "'Both, agriculture and non-agriculture'='Agricultural and non-agricultural'; 
                               'From agricultural activities in other farms'='Agricultural (in other farms)'; 
                               'Non-agricultural activities'='Non-agricultural'")
      M$M3$IVTM = car::recode(M$M3$IVTM, "'Investment for less than 1 year'='Short-term (less than a year)'; 
                               'Investment for more than 1 year'='Long-term (more than a year)'")
      M$M3$CRTM = car::recode(M$M3$CRTM, "'Loan for less than 1 year'='Short-term (less than a year)'; 
                               'Loan for more than 1 year'='Long-term (more than a year)'")
      
      M$M3$CRUS = car::recode(M$M3$CRUS, "'Purchase  management / production inputs'='To purchase  management / production inputs'")
      
      if("SCC1" %in% names(M$M1)){ 
        M$M1$SCC1 = gsub(" in my farm", "", M$M1$SCC1) 
        M$M1$SCC1 = str_to_sentence(M$M1$SCC1, locale = "en")
      }
      if("CCC1" %in% names(M$M1)){ 
        M$M1$CCC1 = gsub(" in my farm", "", M$M1$CCC1) 
        M$M1$CCC1 = str_to_sentence(M$M1$CCC1, locale = "en")
      }
      if("CSC3" %in% names(M$M2)){        
        M$M2$CSC3 = gsub(" in my farm", "", M$M2$CSC3) 
        M$M2$CSC3 = str_to_sentence(M$M2$CSC3, locale = "en")
      }

      if(NombreParaFiltros=="Nepal Nawalparasi"){
        #6.3
        correccion1=M$M5=="I equally contributed (with spouse) - Tôi làm cùng vi các thành viên khác" | M$M5=="I equally contributed (with spouse) -  Tôi làm cùng v<U+1EDB>i các thành viên khác"
        correccion2=M$M5=="Yes, I did most - Có, tôi làm là chính"
        M$M5[correccion1]<-"I equally contributed"
        M$M5[correccion2]<-"Yes, I did most"
        #6.6
        correccion3=M$M5=="Production increased - Sản lượng tăng"
        M$M5[correccion3]<-"Production increased"
        #6.12
        # correccion4=M$M5=="Spent more time - Mất nhiều thời gian hơn"
        # correccion5=M$M5=="The same amount of time - Thời gian không thay đổi"
        # M$M5[correccion4]<-"Spent more time"
        # M$M5[correccion5]<-"The same amount of time"
        require(tidyverse)
        # options(stringsAsFactors = FALSE)
        M$M5=M$M5 %>% 
          mutate(nombres = case_when(P5W2 == "Spent more time - Mất nhiều thời gian hơn" ~ 'Spent more time',
                                     P5W2 == 'The same amount of time - Thời gian không thay đổi' ~ 'The same amount of time'))
        
      }
      
  #   M$M3$IVUS  = car::recode(M$M3$IVUS, "'Mejoras en la infraestructura'='Infraestructura'; 'Para cambiar de tipo de cultivo o de animales criados'='Cambiar cultivos o ganado'; 'Para comprar insumos de producción o de manejo'='Insumos'; 'Para pagar jornales'='Jornales'")
  #   #cambios pagina 3
  #   M$M3$CRSC  = car::recode(M$M3$CRSC, "'Cooperativa o institución de microcrédito'='Cooperativa o microcrédito'; 'De un banco (credito formal)'='Banco'; 'Familia,amigos'='Familia o amigos'; 'Prestamista privado (informal)'='Prestamista privado'")
  #   M$M3$CRUS = car::recode(M$M3$CRUS, "'Para cambiar de tipo de cultivo o de animales criados'='Cambiar cultivos o ganado'; 'Para comprar insumos de producción o de manejo'='Compra de insumos'; 'Para invertir en infraestructura'='Infraestructura'; 'Para pagar jornales'='Pagar jornales'")
  #   M$M3$TRA1 = car::recode(M$M3$TRA1, "'CCAFS'='CCAFS'; 'Compagnia comercial/privada'='Privado'; 'No sabe'='No sabe'; 'Servicio de extensión del gobierno o servicio meteorologico'='extensión del gobierno o meteorologico'; 'Un familiar, vecino o un lider/experto de la comunidad'='Familiar, vecino o lider'")
  #   M$M3$TRF1 = car::recode(M$M3$TRF1, "'CCAFS'='CCAFS'; 'Compagnia comercial/privada'='Privado'; 'No sabe'='No sabe'; 'Servicio de extensión del gobierno o servicio meteorologico'='extensión del gobierno o meteorologico'; 'Un familiar, vecino o un lider/experto de la comunidad'='Familiar, vecino o lider'")
  #   #Cambios pagina 7
  #   M$M2$`CSX6`= car::recode(M$M2$`CSX6`, "'No confié en lainformación/no era suficientemente precisa'='No confié en la información/no era suficientemente precisa'; 'No entendí la información'='No entendí la información'; 'No supe que decición cambiar'='No supe que decisión cambia'; 'No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'='No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'")
  #   if(!is.null(M$M2$`CSD8`)){M$M2$`CSD8`= car::recode(M$M2$`CSD8`, "'No confié en lainformación/no era suficientemente precisa'='No confié en la información/no era suficientemente precisa'; 'No entendí la información'='No entendí la información'; 'No supe que decición cambiar'='No supe que decisión cambia'; 'No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'='No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'")}
  #   if(!is.null(M$M2$`CSS8`)){M$M2$`CSS8`= car::recode(M$M2$`CSS8`, "'No confié en lainformación/no era suficientemente precisa'='No confié en la información/no era suficientemente precisa'; 'No entendí la información'='No entendí la información'; 'No supe que decición cambiar'='No supe que decisión cambia'; 'No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'='No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'")}
     Climate_eventsI=Climate_events %>% select(c("code","En")) %>% rename("code"="code","name"="En")
  #   M$M1$`CCC0`  = car::recode(M$M1$`CCC0`,"'No se realizó ningun cambio'='Sin cambios';
  #                              'Si se realizaron cambios pero no por razones de eventos climáticos'='cambios autónomos';
  #                              'Si, se realizaron cambios en respuesta a eventos climáticos'='cambios en respuesta a eventos climáticos'")
  #   
  # }
  
  #Cambios en las bases de datos de ghana
  #if(TeSACFolders[j]=="Ghana"){
  #    M$M0$HEAD=if_else(M$M1$HEAD=="Yes",1,0,missing = NA) #no saemos lo del missing
  #}
  
     CSA_t=CSA_typology# %>% filter(subgeo==j)
     
     contexto=contextos[TeSACFolders[j]]
     practicas= as.vector(unlist(practica[j]))
     
  ###################################################
  #Implementaron al menos una práctica
  ###################################################
  pra=c("PRA1","PRA2","PRA3","PRA4","PRA5","PRA6","PRA7","PRA8","PRA9","PRA10","PRA11","PRA12")
  varPractices=pra[pra%in%names(M$M5)]
  
  pras=M$M5[,names(M$M5)%in%pra] %>% mutate_if(is.character, as.numeric) %>% rowSums(na.rm = TRUE)
  pras[is.na(pras)]=0
  
  M$M5$implementers=if_else(pras!="0","1","0")
  
  HI=M$M5%>%
    group_by(address)%>%
    summarise(HouseImplementers=sum(as.numeric(implementers)))
  
  HI$HouseImplementers=if_else(HI$HouseImplementers==0,0,1)
  
  M$M5=left_join(M$M5,HI,by="address")
  ###################################################

  ###################################################
  #DES-Implementaron al menos una práctica
  ###################################################
  pra=sprintf("P%sA1",seq(1:12))
  varPractices=pra[pra%in%names(M$M5)]
  
  bddd=M$M5[,names(M$M5)%in%pra] %>% mutate_if(is.character, as.numeric)
  sin_Des=bddd %>%  is.na() %>% rowSums(na.rm = TRUE) == length(varPractices)
  pras=bddd %>% rowSums(na.rm = TRUE)
  pras[is.na(pras)]=0
  pras[sin_Des]=NA
  
  M$M5$Des_implementers=if_else(pras!="0","1","0")
  
  HI=M$M5%>%
    group_by(address)%>%
    summarise(Des_HouseImplementers=sum(as.numeric(Des_implementers)))
  
  HI$Des_HouseImplementers=if_else(HI$Des_HouseImplementers==0,0,1)
  
  M$M5=left_join(M$M5,HI,by="address")
  ###################################################  

  #edades
  M$M0$EDAD=as.numeric(format(Sys.time(), "%Y"))-as.numeric(M$M0$birthyear)
  
   #################################################################
  
  # #Renderizamos la pagina 1
  pra=c("PRA1","PRA2","PRA3","PRA4","PRA5","PRA6","PRA7","PRA8","PRA9","PRA10","PRA11","PRA12")
  varPractices=pra[pra%in%names(M$M5)]
  rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/1_Datos_generales_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))
  #Renderizamos la pagina 2
    rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/2_Medios_de_vida_S_Ghana.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))
  #Renderizamos la pagina 3
    rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/3_Servicios_financieros_2S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))
  #Renderizamos la pagina 4
    rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/4_Seguridad_alimentaria_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))
  #Renderizamos la pagina 5

  thm1$colors=c("#7CB5EC", "#F7A35C", "#90EE7E", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
  thmPIE=thm1
  thmPIE$colors=c( "#f5a9a9","#a9a9f5", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
  thmHS=thm1
  thmHS$colors=c("#b5e6e9","#f5a9a9", "#a9a9f5", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")


  rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/5_Eventos_climaticos_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))
  # Renderizamos la pagina 6
   rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/6 _SA_Practicas_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))
  # #Renderizamos la pagina 7
  rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/7_Servicios_climaticos_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/Ghana/Ghana/",TeSACFolders[j],sep=""))

}
