library("printr")
library("tidyr")
library("readr")
library("dplyr")
library("highcharter")
library(devtools)
library("janitor")
library(devtools)
library(rpivotTable)
library(flextable)
library(officer)
library(httpuv)
library(knitr)
library(kableExtra)
library(car)
library(tools)
library(stringr)


##################################################################################################################################
#MAIN
##################################################################################################################################

#################################################################
##Tema para graficos 
#################################################################
thm1=hc_theme_gridlight()
thm1$title$style$fontSize="24px"
thm1$xAxis$labels$style$fontSize= "18px"
thm1$yAxis$labels$style$fontSize= "18px"
thm1$yAxis$title$style$fontSize= "18px"
thm1$xAxis$title$style$fontSize= "18px"
thm1$tooltip$style$fontSize="16px"
thm1$tooltip$headerFormat='<span style="font-size: 16px">{point.key}</span><br/>'
thm1$tooltip$pointFormat='<span style="color:{point.color}">\u25CF</span> {series.name} <br/> <b>{point.Porcentaje:.0f}%</b>'
thm1$legend$itemStyle$fontSize="18px"
thm1$title$style$textTransform=NULL
thm1$yAxis$title$style$textTransform=NULL
thm1$xAxis$title$style$textTransform=NULL
#7798BF verde que no me gusta
#A1BE95
thm1$colors=c("#7CB5EC", "#F7A35C", "#90EE7E", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
thmPIE=thm1
thmPIE$colors=c("#a9a9f5", "#f5a9a9", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
thmHS=thm1
thmHS$colors=c("#a9f5a9","#a9a9f5", "#f5a9a9", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
#################################################################

#################################################################
##Funciones de tacometros
#################################################################
tacometro1=function(Valor,Nombre,yt=NULL,VR=NULL){
  if(identical(Valor, numeric(0))){
    Valor=0
  }
  if(is.null(yt)){yt=120}
  if(is.null(VR)){stopsCol=c('#DF5353','#DDDF0D','#55BF3B')} #si queremos que el grafico vaya de rojo a verde dejamos el parametro VR en null
  if(!is.null(VR)){stopsCol=c('#55BF3B','#DDDF0D','#DF5353')} #si queremos que vaya de verde a rijo le ponemos cualquier cosa
  
  highchart() %>%
    hc_chart(type = "solidgauge") %>%
    hc_title(y=yt,text = Nombre) %>%
    hc_pane(startAngle = -90,
            endAngle = 90,
            background= list(
              outerRadius = '100%',
              innerRadius = '60%',
              shape="arc"
            )) %>%  
    hc_yAxis(
      stops=list_parse2(data.frame(q = c(0.25,0.75,1), c = stopsCol,stringsAsFactors = FALSE)),
      lineWidth=0,
      minorTickWidth=0,
      tickAmount=2,
      min = 0,
      max = 100,
      labels=list(y=26,style = list(fontSize = "18px"),format = "{value}%")
    ) %>%
    hc_add_series(data = Valor,
                  dataLabels=list(y=-50,borderWidth=0, useHTML=TRUE,style = list(fontSize = "25px"),format = "{point.y}%")) %>%
    hc_add_theme(thm1)%>%
    hc_tooltip(enabled=FALSE)
}
#################################################################
#################################################################

FinishTacometro=function(basetac,filtro,HogarAgri,VR=NULL,NombreM=NULL,NombreH=NULL){
  
  if(is.null(NombreM) & is.null(NombreH)){
    NombreM= "Mujeres"
    NombreH= "Hombres"
  }
  
  In19=basetac %>%
    #filter(`HEAD`==1 | `HEAD`==0)%>%
    group_by_at(c(1,2,3)) %>% 
    summarise(count = n())
  
  names(In19)=c("gender", "HEAD", "variab", "count")
  
  In19=In19[!is.na(In19$variab),]
  
  #In19$`HEAD`=if_else(In19$`HEAD`=="1","Si","No")
  
  Sex=In19 %>% group_by_at(c(1,3)) %>% summarise(count = sum(count)) %>% mutate(prop=round(count/sum(count)*100,0))
  
  SexH=Sex%>%filter(gender=="Hombres" & variab==filtro)
  SexM=Sex%>%filter(gender=="Mujeres" & variab==filtro)
  
  if(HogarAgri=="Hogares"){
    #############
    hogares=In19 %>% na.omit() %>% group_by_at(c(2,3)) %>% summarise(count = sum(count)) %>% mutate(prop=round(count/sum(count)*100,0))
    
    hogares1=hogares %>% filter(`HEAD`==1 & variab==filtro)
    
    names(hogares)=c("Hogares","count","prop")
    ##########
    return(hw_grid(tacometro1(hogares1$prop,"Hogares",VR=VR),tacometro1(SexH$prop,NombreH,VR=VR),tacometro1(SexM$prop,NombreM,VR=VR)))
  }
  
  else{
    Agric=basetac %>%
      #filter(`HEAD`==1 | `HEAD`==0)%>%
      group_by_at(c(3)) %>% 
      summarise(count = n())%>%
      na.omit()%>% 
      mutate(prop=round(count/sum(count)*100,0))
    
    names(Agric)=c("variab", "count","prop")
    
    Agric=Agric%>% 
      filter(variab==filtro)
    
    return(hw_grid(tacometro1(Agric$prop,"Agricultores",VR=VR),tacometro1(SexM$prop,NombreM,VR=VR),tacometro1(SexH$prop,NombreH,VR=VR)))
  }
}
#################################################################


#################################################################
#Funci?n para multiple Choise
#################################################################
multiple_Choise=function(base19,VariA){
  retornador=list()
  I45c=list()
  I45cH=list()
  Variable=base19[,VariA]
  
  #Desintegramos la variables usando los | como separadores
  yy = Map(function(x,y)cbind.data.frame(y,x),strsplit(Variable,"|",fixed=TRUE),base19$farmer_id)
  base19EX=do.call("rbind",yy)
  names(base19EX)=c("farmer_id","pre")
  base19EX=merge(base19EX,base19[c("farmer_id","gender","HEAD")],by="farmer_id")
  
  #CIAT/ NOMASI/ CCAFS | Commercial / private company | Don't know | Government agricultural extension or Meteorogical office | Relative, neighbor or expert within the community

    I45c=base19EX %>%
      filter(!is.na(pre))%>%
      group_by(gender,pre) %>%
      summarise(count = n()) %>%
      merge(base19 %>%
              filter(!is.na(Variable))%>%
              group_by(gender) %>%
              summarise(N = n()),by="gender")%>%
      mutate(prop=round(count/N*100))%>%
      select(c("gender","pre","prop","N"))
    
    retornador$TablaGBruta1=I45c2=I45c
    
    I45c2$prop=paste(I45c2$prop,"%",sep="")
    
    retornador$TablaGBruta=I45c2%>%
      rename("Porcentaje"="prop","Numero de Agricultores"="gender") %>% 
      select(c("Numero de Agricultores","pre","Porcentaje","N"))%>%
      spread("pre", Porcentaje, fill="0%")
    
    
    
    retornador$TablaG=retornador$TablaGBruta%>% 
      kable() %>%
      kable_styling("striped", full_width = F)
    
    retornador$hcG=hchart(I45c, "column", hcaes(x = pre, y = prop, group=`gender`),
                          dataLabels = list(enabled = TRUE,format = paste('<b>{point.prop}%</b>'), style=list(fontSize="17px"))) %>%
      hc_tooltip(pointFormat = paste('<b>{point.prop}%</b>'))%>%
      hc_title(text = paste(" "),
               margin = 20, align = "center",style = list(useHTML = TRUE)) %>%
      # hc_legend(align = "center")%>%
      hc_add_theme(thmPIE)%>%
      hc_xAxis(title = list(text = " ")) %>%
      hc_yAxis(title = list(text = "Porcentaje de Agricultores"),labels = list(format = "{value}%"), max = 100)
    
    
    #Lo mismo pero para agricultores en general
    
    I45cH=base19EX %>%
      #filter(`HEAD`=="1") %>%
      filter(!is.na(pre))%>%
      group_by(pre) %>%
      summarise(count = n()) %>%
      merge(base19 %>%
              filter(!is.na(Variable)) %>% # & `HEAD`==1)%>%
              summarise(N = n()))%>%
      mutate(prop=round(count/N*100))%>%
      select(c("pre","prop","N"))

    retornador$TablaFBruta1=I45cH2=I45cH
    
    I45cH2$prop=paste(I45cH2$prop,"%",sep="")
    
    retornador$TablaFBruta=I45cH2%>%
      rename("Porcentaje"="prop") %>% 
      mutate("Numero de Agricultores"="Agricultores") %>% 
      select(c("Numero de Agricultores","pre","Porcentaje","N"))%>%
      spread("pre", Porcentaje, fill="0%")
    
    retornador$TablaF=retornador$TablaFBruta %>% 
      kable() %>%
      kable_styling("striped", full_width = F)
    
    retornador$hcF=hchart(I45cH, "column", hcaes(x = pre, y = prop),
           dataLabels = list(enabled = TRUE,format = paste('<b>{point.prop}%</b>'), style=list(fontSize="17px"))) %>%
      hc_tooltip(pointFormat = paste('<b>{point.prop}%</b>'))%>%
      hc_title(text = paste(" "),
               margin = 20, align = "center",style = list(useHTML = TRUE)) %>%
      # hc_legend(align = "center")%>%
      hc_add_theme(thm1)%>%
      hc_xAxis(title = list(text = " ")) %>%
      hc_yAxis(title = list(text = "Porcentaje de Agricultores"),labels = list(format = "{value}%"), max = 100)
  
    retornador$tablaFyG=dplyr::bind_rows(retornador$TablaFBruta,retornador$TablaGBruta)%>% 
                                  kable() %>%
                                  kable_styling("striped", full_width = F)
    
    I45cH=I45cH %>% mutate(gender="Agricultores")
    
    tablaFyGBruta=dplyr::bind_rows(I45c,I45cH)
    retornador$tablaFyGBruta=tablaFyGBruta
    
    retornador$HFandHM=hchart(tablaFyGBruta, "column", hcaes(x = pre, y = prop,group=gender),
                          dataLabels = list(enabled = TRUE,format = paste('<b>{point.prop}%</b>'), style=list(fontSize="13px"))) %>%
      hc_tooltip(pointFormat = paste('<b>{point.prop}%</b>'))%>%
      hc_title(text = paste(" "),
               margin = 20, align = "center",style = list(useHTML = TRUE)) %>%
      # hc_legend(align = "center")%>%
      hc_add_theme(thmHS)%>%
      hc_xAxis(title = list(text = " ")) %>%
      hc_yAxis(title = list(text = "Porcentaje de Agricultores"),labels = list(format = "{value}%"), max = 100)
    
    return(retornador)
}

#################################################################
##Funci?n arreglador, para las preguntas donde se pod?a devolver y no se reescrib?a la informaci?n
#################################################################
arreglador=function(cadena){
  patron="\\|"
  answer_type=if_else(c("multiple_choice") %in% cadena,"multiple_choice","Other_type")
  
  if(answer_type!="multiple_choice" & sum(grepl(patron, cadena))!=0){
    cadena2=grep(pattern = patron, cadena, value = T)
    posiciones=stringr::str_locate_all(cadena2, patron)
    posiciones2=lapply(posiciones, max)
    cadena2=substr(cadena2, unlist(posiciones2, use.names=FALSE)+1, nchar(cadena2))
    cadena=replace(cadena,which(grepl("\\|", cadena)),cadena2)
    return(cadena)
  }
  if(answer_type=="multiple_choice" | sum(grepl(patron, cadena))==0){
    return(cadena)
  }
}

#################################################################
#Carga de bases de datos.
#################################################################
#D:\OneDrive - CGIAR\Documents\Paginas de procesamiento rapido\XXXXX\New Codes

bases=NULL
M2=NULL
#Uganda = hoima
#
TeSACFolders=c("Olopa","Nicaragua","Santa Rita","Cauca")
idiomas=c("es")

for(p in 1:length(TeSACFolders)){
  for (i in 0:5){
    M2[[i+1]]<- read_delim(paste("D:/OneDrive - CGIAR/Documents/Paginas de procesamiento rapido/",TeSACFolders[p],"/New Codes/M",i,".csv",sep=""), 
                           "\t", escape_double = FALSE, trim_ws = TRUE)
    #, locale = locale(encoding = 'ISO-8859-1')
    M2[[i+1]][M2[[i+1]]=="Yes"]=1
    M2[[i+1]][M2[[i+1]]=="No"]=0
  
    M2[[i+1]]=apply(M2[[i+1]], 2, arreglador) %>% as.data.frame()
    #M2[[i+1]]=lapply(M2[[i+1]], as.character) %>% as.data.frame()
    M2[[i+1]] <- data.frame(lapply(M2[[i+1]], as.character), stringsAsFactors=FALSE)
    
    }
  names(M2)=c("M0","M1","M2","M3","M4","M5")
  bases[[p]]=M2
}
names(bases)=TeSACFolders
#################################################################


#################################################################
#Carga de questionarios
#################################################################
#D:\OneDrive - CGIAR\Documents\Indicadores sistematizados\Ghana\Ghana\Questions\Questions_

#Uganda = hoima
#
# TeSACFolders=c("Ghana","Uganda","Bangladesh Khulna","Bangladesh barisal","Nepal Nawalparasi")
TeSACFolders=c("Olopa","Nicaragua","Santa Rita","Cauca")


Questions=NULL

for(p in 1:length(TeSACFolders)){
  Questions[[p]] <- read_excel(paste("Questions/Questions_",TeSACFolders[p],".xlsx",sep=""), 
                           col_types = c("blank", "blank", "blank", 
                                         "text", "blank", "text", "text", 
                                         "blank")) %>% t()
  colnames(Questions[[p]])=Questions[[p]][1,]
  Questions[[p]]=Questions[[p]][c(2,3),] %>% as.data.frame()
}
names(Questions)=TeSACFolders

#################################################################

#################################################################
#Nombres de pr?cticas por TeSAC
#################################################################
practica=NULL
#practica$Olopa=c("Variedades mejoradas de frijol","Huerto de hortalizas con cosecha de agua","Huerto de hortalizas sin cosecha de agua","Riego")
#practica$Cauca=c("Frijol restistente a sequia/biofortificado","Abono org?nico","Huerta adaptada al clima","Barreras rompe viento","Retenci?n/incorporaci?n de residuos de cultivos","Cosecha de agua","implement? Riego","Almacenamiento de agua en tanques de ferrocemento","Bomba tipo cam?ndula")
#practica$`Santa Rita`=c("Variedades mejoradas de frijol rojo","Huertas de hortalizas con cosecha de agua","Huertas de hortalizas sin cosecha de agua","Secadoras solares de granos")
#practica$Nicaragua=c("Diversificaci?n de cultivos y actividades productivas en el patio","Cultivos perennes y sistemas ganaderos con sombra diversificada y regulada","No quema y uso de residuos como cobertura muerta en cultivos anuales","Proteci?n de fuentes de agua en la finca","Uso de opciones no sint?ticas para fertilizaci?n y manejo de plagas y enfermedades en cultivos","Uso de variedades m?s tolerantes o mejor adaptadas a condiciones adversas del clima")
#practica$Ghana=c("crop rotation","improved varieties","integrated nutrient management","intercropping","mulching","no/reduced tillage","new cropping system & additional crops (Home gardens)")
#practica$Uganda=c()
#practica$Bangladesh_Khulna=c("crop rotation","improved varieties","integrated nutrient management","intercropping","mulching","no/reduced tillage","new cropping system & additional crops (Home gardens)")
#practica$Bangladesh_barisal=c("crop rotation","improved varieties","integrated nutrient management","intercropping","mulching","no/reduced tillage","new cropping system & additional crops (Home gardens)")
#practica$Nepal_Nawalparasi=c()
#################################################################

#################################################################
#Funcion para dejar los nuevos codigos como nombres de las variables (tambien quita las preguntas y los tipos de variables.)
#################################################################
cambCod <- function(BD){
  
  ##########CONSIDERAR LOS IDIOMAS PARA QUE NO CAMBIO EL GENDER EN LOS SITIOS EN INGLES  
  BD$gender = car::recode(BD$gender, "'female'='Mujeres'; 'male'='Hombres'")
  
  New_codes <-BD %>% filter(farmer_id=="QUESTION" | farmer_id=="QUESTION_CODE" )%>% t()%>% as.data.frame()
  New_codes$old_codes=row.names(New_codes)
  names(New_codes)=c("question","new_codes","old_codes")
  New_codes$new_codes=as.character(New_codes$new_codes)
  New_codes$new_codes[New_codes$new_codes=="QUESTION_CODE"]="--"
  New_codes$new_codes[is.na(New_codes$new_codes)]="--"
  New_codes$question[New_codes$question=="QUESTION"]="--"
  
  New_codes$new_codes[New_codes$new_codes=="--"]=New_codes$old_codes[New_codes$new_codes=="--"]
  
  BD=BD %>% filter(farmer_id!="QUESTION TYPE" & farmer_id!="QUESTION" & farmer_id!="QUESTION_CODE")
  BD=BD[,!names(BD)%in%c("X__1")]
  
  New_codes2=New_codes %>% filter(old_codes%in%names(BD)) %>% select(new_codes)
  names(BD)= New_codes2$new_codes
  
  return(BD)
}
#################################################################

#################################################################
#TypeVar Funcion que deja un data frame con el code de la variable y el tipo de variable, necesario para algunos filtros
#################################################################
# TypeVar <- function(BD){
#   
#   ##########CONSIDERAR LOS IDIOMAS PARA QUE NO CAMBIO EL GENDER EN LOS SITIOS EN INGLES  
#   BD$gender = car::recode(BD$gender, "'Mujeres'='Mujeres'; 'Hombres'='Hombres'")
#   
#   New_codes <-BD %>% filter(farmer_id=="QUESTION" | farmer_id=="QUESTION_CODE" )%>% t()%>% as.data.frame()
#   New_codes$old_codes=row.names(New_codes)
#   names(New_codes)=c("question","new_codes","old_codes")
#   New_codes$new_codes=as.character(New_codes$new_codes)
#   New_codes$new_codes[New_codes$new_codes=="QUESTION_CODE"]="--"
#   New_codes$new_codes[is.na(New_codes$new_codes)]="--"
#   New_codes$question[New_codes$question=="QUESTION"]="--"
#   
#   New_codes$new_codes[New_codes$new_codes=="--"]=New_codes$old_codes[New_codes$new_codes=="--"]
#   
#   #farmer_id=="QUESTION TYPE" & 
#   BD=BD %>% filter(farmer_id!="QUESTION" & farmer_id!="QUESTION_CODE")
#   BD=BD[,!names(BD)%in%c("X__1")]
#   
#   New_codes2=New_codes %>% filter(old_codes%in%names(BD)) %>% select(new_codes)
#   names(BD)= New_codes2$new_codes
#   
#   BD=BD %>% filter(farmer_id=="QUESTION TYPE")
#   
#   return(BD)
# }
# #################################################################
# 
# #################################################################
# #QuestionVar Funcion que deja un data frame con el code de la variable y als preguntas
# #################################################################
# QuestionVar <- function(BD){
#   
#   ##########CONSIDERAR LOS IDIOMAS PARA QUE NO CAMBIO EL GENDER EN LOS SITIOS EN INGLES  
#   BD$gender = car::recode(BD$gender, "'Mujeres'='Mujeres'; 'Hombres'='Hombres'")
#   
#   New_codes <-BD %>% filter(farmer_id=="QUESTION" | farmer_id=="QUESTION_CODE" )%>% t()%>% as.data.frame()
#   New_codes$old_codes=row.names(New_codes)
#   names(New_codes)=c("question","new_codes","old_codes")
#   New_codes$new_codes=as.character(New_codes$new_codes)
#   New_codes$new_codes[New_codes$new_codes=="QUESTION_CODE"]="--"
#   New_codes$new_codes[is.na(New_codes$new_codes)]="--"
#   New_codes$question[New_codes$question=="QUESTION"]="--"
#   
#   New_codes$new_codes[New_codes$new_codes=="--"]=New_codes$old_codes[New_codes$new_codes=="--"]
#   
#   #farmer_id=="QUESTION TYPE" & 
#   BD=BD %>% filter(farmer_id!="QUESTION TYPE" & farmer_id!="QUESTION_CODE")
#   BD=BD[,!names(BD)%in%c("X__1")]
#   
#   New_codes2=New_codes %>% filter(old_codes%in%names(BD)) %>% select(new_codes)
#   names(BD)= New_codes2$new_codes
#   
#   BD=BD %>% filter(farmer_id=="QUESTION")
#   
#   return(BD)
# }
# #################################################################


#################################################################
#lapply anidado, funcion para aplicar la funci?n anterior a todas las bases
#################################################################
nested_lapply <- function(data, fun) {
  lapply(data, function(sublist) { lapply(sublist, fun) })
}
#################################################################

#Base definitiva con la que vamos a trabajar
bases_New_Codes=nested_lapply(bases,cambCod)
#bases_TypeVar=nested_lapply(bases,TypeVar)
#bases_QuestionVar=nested_lapply(bases,QuestionVar)

#################################################################
#Contextos para cada uno de los TeSAC
#################################################################
contextos=NULL
contextos$Olopa="El municipio de Olopa pertenece al departamento de Chiquimula en el oriente de Guatemala. En el a?o 2005, su ?ndice de Desarrollo Humano (IDH) fue estimado en 0.448, lo que, comparado con IDH promedio del pa?s de 0.580, lo ubicaba por debajo de la media nacional. Al analizar los ?ndices de salud y educaci?n para el mismo a?o, se aprecia que ellos est?n por debajo del ?ndice nacional (0.409 versus 0.807 para el ?ndice de salud y 0.383 versus 0.452 para el ?ndice de educaci?n). Contrariamente, el ?ndice de ingreso per c?pita en Olopa de 0.552 , se ubicaba por encima del ?ndice nacional de 0.534 (PNUD, 2011; PNUD 2012). El caf? es base de la econom?a, sin embargo, son una poblaci?n con altos niveles de vulnerabilidad. \n \n \n Olopa tiene una poblaci?n estimada de 23.668 habitantes con una densidad poblacional de 211 habitantes km-1. El 65% de la poblaci?n del municipio pertenece a la etnia ch'orti'. De acuerdo con el PIDET (2013), la distribuci?n de la poblaci?n es de 51% mujeres y 49% varones. \n \n \n https://ccafs.cgiar.org/es/tesac-olopa-guatemala#.XMiy17vPzIV"
contextos$Nicaragua="El Municipio de El Tuma-La Dalia est? ubicado en el noroeste del departamento de Matagalpa. Tiene una extensi?n de 650.3 km2 y una poblaci?n de 56.681 habitantes (INIDE 2006), de los cuales el 85 % es rural y 15 % urbana. Posee una poblaci?n muy joven, como en el resto del pa?s, donde m?s del 52 % es menor de 16 a?os. Las mujeres conforman el 49.3 %, 2.7 % menos que la media nacional y 4.7 % que la media departamental.  \n \n \n Tuma-La Dalia presenta un clima caracter?stico de bosque subtropical, semi-h?medo. La temperatura media anual es de 22.6?C y la precipitaci?n media anual es de 1404 mm, con un periodo lluvioso y uno seco. La ?poca de lluvias se extiende de junio a noviembre con un patr?n bimodal de m?ximas precipitaciones en los meses de julio y noviembre con una precipitaci?n promedio mensual de 210 y 213 mm respectivamente. La can?cula se da entre julio y agosto, y que presenta diferentes grados de afectaci?n de acuerdo a la duraci?n de la misma. El periodo seco dura 5-6 meses (diciembre a mayo), siendo el mes m?s seco abril en donde la precipitaci?n promedio mensual puede disminuir a 19.2 mm.\n \n \n https://ccafs.cgiar.org/es/tesac-el-tuma-la-dalia-nicaragua#.XMizarvPzIU"
contextos$`Santa Rita`="El TeSAC Santa Rita se ubica en el departamento de Copan, occidente de Honduras. El departamento tiene un ?ndice de Desarrollo Humano (IDH) del 0,632, ocupando el lugar 14 (de 18 departamentos) a nivel nacional (PNUD 2012).  \n \n \n Santa Rita cuenta con una poblaci?n total proyectada al a?o 2016 de 30.682 habitantes de los cuales el 50,3% son hombres y el 49,3% mujeres; 14,8% habita en ?reas urbanas y el 85,2% en ?reas rurales, es por ello que los principales medios de vida est?n relacionados con actividades agr?colas y ganaderas. La densidad poblacional es de 105.18 ab/km2. \n \n \n https://ccafs.cgiar.org/es/tesac-santa-rita-honduras#.XMizsLvPzIU"
contextos$Cauca="El TeSAC Cauca se ubica en el noroccidente del municipio de Popay?n, capital del departamento del Cauca. Las comunidades de estas veredas se han fortalecido y empoderado a trav?s de la Asociaci?n de Juntas de Acci?n Comunal (JAC) para buscar mecanismos que generen sostenibilidad y mejoren su calidad de vida, enfrentado retos como los impactos de la variabilidad y cambio clim?tico, que generan disminuci?n de la productividad y rendimiento en sus cultivos, problemas en el acceso al recurso h?drico, degradaci?n de los suelos, entre otros. \n \n \n El entusiasmo de estas comunidades por hacer que sus tierras sean productivas es grande, a pesar de que como ellos mismos manifiestan, el clima ya no es como antes (sic); pero es mayor su deseo que sus hijos y nietos puedan seguir viviendo de ellas. Esa es la motivaci?n principal por la cual buscan sacarle provecho no s?lo al clima, sino a los diversos retos en el contexto social, econ?mico y pol?tico del pa?s. \n \n \n https://ccafs.cgiar.org/es/tesac-cauca-colombia#.XMizD7vPzIU"

#################################################################

#################################################################
#Funci?n donde
#################################################################
recodificaciones <- function(M, j) {
  lapply(data, function(sublist) { lapply(sublist, fun) })
}
#################################################################

#################################################################
#Esta base contiene los codigos y los nombres de las practicas por TeSAC
#################################################################
library(readxl)
#CSA_typology <- CSA_typology2 %>%  filter(subgeo==5)

CSA_typology2 <- read_excel("CSA_typology.xlsx") 
practica=NULL

for(k in 1:length(TeSACFolders)){
  CSA_typology3 = CSA_typology2 %>% filter(subgeo==k)
  practica[[k]]=CSA_typology3$CSA_practice_name
}

names(practica)=TeSACFolders

Climate_events <- read_excel("Climate_events.xlsx",na = "NA")
#################################################################

#################################################################
#Base de datos que contiene el inicio de las preguntas "automaticas"
#################################################################
Quest <- read_excel("Quest.xlsx")
#################################################################

#################################################################
####TITULOS PAGINAS INDEX
#################################################################
tit=NULL
tit$olopa="Olopa (Guatemala)"
tit$Tuma="Tuma la dalia (Nicaragua)"
tit$SataRita="Santa Rita (Honduras)"
tit$Cauca="Cauca (Colombia)"

TitulosIndex=NULL
for(j in 1:length(TeSACFolders)){
  TitulosIndex[j]=paste("<H1> Monitoreo clim?tico inteligente 2018: adopci?n de pr?cticas ASAC y resultados en ",tit[[j]],"</H1>",sep="")
}



for (j in 1:length(TeSACFolders)) {

  NombreParaFiltros=TeSACFolders[j]
  
  CSA_typology <- CSA_typology2 %>%  filter(subgeo==j)
  
  M=bases_New_Codes[[TeSACFolders[j]]]
  M_TypeVar=Questions[[j]][2,]
  M_TypeVar=lapply(M_TypeVar, as.character)

  M_QuestionVar=Questions[[j]][1,]
  M_QuestionVar=lapply(M_QuestionVar, as.character)
  #idioma=idiomas[j]
  
  # if(idioma=="es"){
  #   #################################################################
  #   # se encuentran las recodificaciones de las bases
  #   #################################################################
  #   #Algunos cambios peque?os que le hacemos a las bases
  #   #cambios pagina 1
  #     M$M1$CCC0 = car::recode(M$M1$CCC0, "'I  did changes but not because of climate'='Autonomous change (not because of climate)'; 
  #                              'Yes, changes were done because of climate'='Climate driven changes';
  #                             'I did not do any change at all'='Without changes'")
  #     M$M1$CCA0 = car::recode(M$M1$CCA0, "'I  did changes but not because of climate'='Autonomous change (not because of climate)'; 
  #                                         'Yes, changes were done because of climate'='Climate driven changes';
  #                                         'I did not do any change at all'='Without changes';
  #                                         'I did not have livestock'='Without livestock'")
  # #   #cambios pagina 2
  #     M$M3$OFTY  = car::recode(M$M3$OFTY, "'Both, agriculture and non-agriculture'='Agricultural and non-agricultural'; 
  #                              'From agricultural activities in other farms'='Agricultural (in other farms)'; 
  #                              'Non-agricultural activities'='Non-agricultural'")
  #     M$M3$IVTM = car::recode(M$M3$IVTM, "'Investment for less than 1 year'='Short-term (less than a year)'; 
  #                              'Investment for more than 1 year'='Long-term (more than a year)'")
  #     M$M3$CRTM = car::recode(M$M3$CRTM, "'Loan for less than 1 year'='Short-term (less than a year)'; 
  #                              'Loan for more than 1 year'='Long-term (more than a year)'")
  #     
  #     M$M3$CRUS = car::recode(M$M3$CRUS, "'Purchase  management / production inputs'='To purchase  management / production inputs'")
  #     
  #     if("SCC1" %in% names(M$M1)){ 
  #       M$M1$SCC1 = gsub(" in my farm", "", M$M1$SCC1) 
  #       M$M1$SCC1 = str_to_sentence(M$M1$SCC1, locale = "en")
  #     }
  #     if("CCC1" %in% names(M$M1)){ 
  #       M$M1$CCC1 = gsub(" in my farm", "", M$M1$CCC1) 
  #       M$M1$CCC1 = str_to_sentence(M$M1$CCC1, locale = "en")
  #     }
  #     if("CSC3" %in% names(M$M2)){        
  #       M$M2$CSC3 = gsub(" in my farm", "", M$M2$CSC3) 
  #       M$M2$CSC3 = str_to_sentence(M$M2$CSC3, locale = "en")
  #     }

      
      
    #cambios pagina 1
    M$M3$ADIC = car::recode(M$M3$ADIC, "'No tuvimos otros ingresos'='Sin fuentes adicionales'; 'Si,dinero enviado por un familiar que no vive en la finca'='Remesas'; 'Si,subsidios del gobierno'='Subsidios'; 'Si,una pens?n'='Pensi?n'")
    #cambios pagina 2
    M$M3$IVUS  = car::recode(M$M3$IVUS, "'Mejoras en la infraestructura'='Infraestructura'; 'Para cambiar de tipo de cultivo o de animales criados'='Cambiar cultivos o ganado'; 'Para comprar insumos de producci?n o de manejo'='Insumos'; 'Para pagar jornales'='Jornales'")
    M$M3$OFTY = car::recode(M$M3$OFTY, "'De actividades agricolas desarrolladas en otras fincas'='Actividades agricolas desarrolladas en otras fincas'")
    M$M3$ADIC = car::recode(M$M3$ADIC, "'Si,una pensi?n'='Pensi?n'")
    #cambios pagina 3
    if("SERK" %in% names(M$M3)){
      M$M3$SERK = gsub("Riezgo", "Riesgo", M$M3$SERK) 
      M$M3$SERK = gsub("riezgo", "riesgo", M$M3$SERK) 
      M$M3$SERK = str_to_sentence(M$M3$SERK, locale = "es")
    }
    
    M$M3$CRSC  = car::recode(M$M3$CRSC, "'Cooperativa o instituci?n de microcr?dito'='Cooperativa o microcr?dito'; 'De un banco (credito formal)'='Banco'; 'Familia,amigos'='Familia o amigos'; 'Prestamista privado (informal)'='Prestamista privado'")
    M$M3$CRUS = car::recode(M$M3$CRUS, "'Para cambiar de tipo de cultivo o de animales criados'='Cambiar cultivos o ganado'; 'Para comprar insumos de producci?n o de manejo'='Compra de insumos'; 'Para invertir en infraestructura'='Infraestructura'; 'Para pagar jornales'='Pagar jornales'")
    M$M3$TRA1 = car::recode(M$M3$TRA1, "'CCAFS'='CCAFS'; 'Compagnia comercial/privada'='Privado'; 'No sabe'='No sabe'; 'Servicio de extensi?n del gobierno o servicio meteorologico'='extensi?n del gobierno o meteorologico'; 'Un familiar, vecino o un lider/experto de la comunidad'='Familiar, vecino o lider'")
    M$M3$TRF1 = car::recode(M$M3$TRF1, "'CCAFS'='CCAFS'; 'Compagnia comercial/privada'='Privado'; 'No sabe'='No sabe'; 'Servicio de extensi?n del gobierno o servicio meteorologico'='extensi?n del gobierno o meteorologico'; 'Un familiar, vecino o un lider/experto de la comunidad'='Familiar, vecino o lider'")
    #Cambios pagina 7
    if(!is.null(M$M2$`CSX6`)){M$M2$`CSX6`= car::recode(M$M2$`CSX6`, "'No confi? en lainformaci?n/no era suficientemente precisa'='No confi? en la informaci?n/no era suficientemente precisa'; 'No entend? la informaci?n'='No entend? la informaci?n'; 'No supe que decici?n cambiar'='No supe que decisi?n cambia'; 'No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'='No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'")}
    if(!is.null(M$M2$`CSD8`)){M$M2$`CSD8`= car::recode(M$M2$`CSD8`, "'No confi? en lainformaci?n/no era suficientemente precisa'='No confi? en la informaci?n/no era suficientemente precisa'; 'No entend? la informaci?n'='No entend? la informaci?n'; 'No supe que decici?n cambiar'='No supe que decisi?n cambia'; 'No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'='No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'")}
    if(!is.null(M$M2$`CSS8`)){M$M2$`CSS8`= car::recode(M$M2$`CSS8`, "'No confi? en lainformaci?n/no era suficientemente precisa'='No confi? en la informaci?n/no era suficientemente precisa'; 'No entend? la informaci?n'='No entend? la informaci?n'; 'No supe que decici?n cambiar'='No supe que decisi?n cambia'; 'No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'='No tenia los recursos/medios para tomar otras decisiones de manjo de la finca'")}
    Climate_eventsI=Climate_events %>% select(c("code","Es")) %>% rename("code"="code","name"="Es")
    M$M1$`CCC0`  = car::recode(M$M1$`CCC0`,"'No se realiz? ningun cambio'='Sin cambios';
                               'Si se realizaron cambios pero no por razones de eventos clim?ticos'='Cambios aut?nomos';
                               'Si, se realizaron cambios en respuesta a eventos clim?ticos'='Cambios en respuesta a eventos clim?ticos'")
    M$M1$`CCA0`  = car::recode(M$M1$`CCA0`,"'No se realiz? ningun cambio'='Sin cambios';
                               'Si se realizaron cambios pero no por razones de eventos clim?ticos'='Cambios aut?nomos';
                               'Si, se realizaron cambios en respuesta a eventos clim?ticos'='Cambios en respuesta a eventos clim?ticos'")
    
  # }
  
  # Cambios en las bases de datos de ghana
  # if(TeSACFolders[j]=="Ghana"){
  #    M$M0$HEAD=if_else(M$M1$HEAD=="Yes",1,0,missing = NA) #no saemos lo del missing
  # }
  
     CSA_t=CSA_typology# %>% filter(subgeo==j)
     
     contexto=contextos[TeSACFolders[j]]
     practicas= as.vector(unlist(practica[j]))
     
  ###################################################
  #Implementaron al menos una pr?ctica
  ###################################################
  pra=c("PRA1","PRA2","PRA3","PRA4","PRA5","PRA6","PRA7","PRA8","PRA9","PRA10","PRA11","PRA12")
  varPractices=pra[pra%in%names(M$M5)]
  
  pras=M$M5[,names(M$M5)%in%pra] %>% mutate_if(is.character, as.numeric) %>% rowSums(na.rm = TRUE)
  pras[is.na(pras)]=0
  
  M$M5$implementers=if_else(pras!="0","1","0")
  
  HI=M$M5%>%
    group_by(address)%>%
    summarise(HouseImplementers=sum(as.numeric(implementers)))
  
  HI$HouseImplementers=if_else(HI$HouseImplementers==0,0,1)
  
  M$M5=left_join(M$M5,HI,by="address")
  ###################################################

  ###################################################
  #DES-Implementaron al menos una pr?ctica
  ###################################################
  pra=sprintf("P%sA1",seq(1:12))
  varPractices=pra[pra%in%names(M$M5)]
  
  bddd=M$M5[,names(M$M5)%in%pra] %>% mutate_if(is.character, as.numeric)
  sin_Des=bddd %>%  is.na() %>% rowSums(na.rm = TRUE) == length(varPractices)
  pras=bddd %>% rowSums(na.rm = TRUE)
  pras[is.na(pras)]=0
  pras[sin_Des]=NA
  
  M$M5$Des_implementers=if_else(pras!="0","1","0")
  
  HI=M$M5%>%
    group_by(address)%>%
    summarise(Des_HouseImplementers=sum(as.numeric(Des_implementers)))
  
  HI$Des_HouseImplementers=if_else(HI$Des_HouseImplementers==0,0,1)
  
  M$M5=left_join(M$M5,HI,by="address")
  ###################################################  

  #edades
  M$M0$EDAD=as.numeric(format(Sys.time(), "%Y"))-as.numeric(M$M0$birthyear)
  
   #################################################################
  
  #P?gina Index
    # rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/Index.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  
  # #Renderizamos la pagina 1
  pra=c("PRA1","PRA2","PRA3","PRA4","PRA5","PRA6","PRA7","PRA8","PRA9","PRA10","PRA11","PRA12")
  varPractices=pra[pra%in%names(M$M5)]
  
  #   rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/1_Datos_generales_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  # # # #Renderizamos la pagina 2
  #   rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/2_Medios_de_vida_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  # # # #Renderizamos la pagina 3
  # rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/3_Servicios_financieros_2S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  # # #Renderizamos la pagina 4
  # rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/4_Seguridad_alimentaria_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  # # #Renderizamos la pagina 5
  # # 
  # thm1$colors=c("#7CB5EC", "#F7A35C", "#90EE7E", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
  # thmPIE=thm1
  # thmPIE$colors=c("#a9a9f5", "#f5a9a9", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
  # thmHS=thm1
  # thmHS$colors=c("#a9f5a9","#a9a9f5", "#f5a9a9", "#7CB5EC", "#7798BF", "#AAEEEE", "#FF0066", "#EEAAEE", "#A1BE95")
  # 
  # rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/5_Eventos_climaticos_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  # # # Renderizamos la pagina 6
  rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/6_SA_Practicas_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))
  # #Renderizamos la pagina 7
  # rmarkdown::render("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/7_Servicios_climaticos_S.Rmd",output_dir = paste("D:/OneDrive - CGIAR/Documents/Indicadores sistematizados/LAM/",TeSACFolders[j],sep=""))

}

